fx_version 'cerulean'
game 'gta5'

author 'Minion'
description 'Christmas xenon and neon fog lights for NPC and player vehicles'
version '1.0.0'

client_scripts {
    'config.lua',
    'main.lua'
}

dependency '/assetpacks'