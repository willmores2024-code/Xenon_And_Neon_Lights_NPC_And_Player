Config = {}

-- NEON
Config.EnableNeonNPC = true      -- Enable neon lights on NPC vehicles
Config.EnableNeonPlayer = true   -- Enable neon lights on player vehicles

-- XENON
Config.EnableXenonNPC = true     -- Enable xenon headlights on NPC vehicles
Config.EnableXenonPlayer = true  -- Enable xenon headlights on player vehicles

-- Weather conditions that trigger Mode 1 when ColorMode = 3
Config.WeatherMode1List = {
	"RAIN",         -- Rain (enabled by default)
    "THUNDER",      -- Thunderstorm (enabled by default)
    "BLIZZARD",     -- Blizzard (enabled by default)
    --"EXTRASUNNY",   -- Extra sunny
    --"CLEAR",        -- Clear sky
    --"NEUTRAL",      -- Neutral weather
    "SMOG",         -- Smog (enabled by default)
    "FOGGY",        -- Foggy (enabled by default)
    --"OVERCAST",     -- Overcast
    --"CLOUDS",       -- Cloudy
    --"CLEARING",     -- Clearing
    --"SNOW",         -- Snow
    "SNOWLIGHT",    -- Light snow
    "XMAS",         -- Christmas-themed weather (enabled by default)
    --"HALLOWEEN"     -- Halloween-themed weather
}

-- Headlight color mode:
-- 1 = Always use "fog-light style" xenon (nearest predefined color ID)
-- 2 = Always use full RGB xenon (exact vehicle color)
-- 3 = Use Mode 1 during weather conditions listed above; otherwise use Mode 2
Config.ColorMode = 3

-- Performance settings
Config.PlayerUpdateInterval = 5000   -- Update interval (in ms) for the player's vehicle
Config.NPCUpdateInterval    = 500   -- Update interval (in ms) for NPC vehicles
Config.MaxVehicleDistance   = 320.0  -- Maximum distance (in units) at which NPC vehicles are processed
